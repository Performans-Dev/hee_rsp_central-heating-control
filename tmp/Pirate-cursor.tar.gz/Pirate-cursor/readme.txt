Date: Jan 05 2025
Product's name: Pirate-cursor
author: Darkeye90 

Definition:
==========
Pirate sword and captain silver hands cursor theme 

I've made it with Inkscape and GIMP

I hope you like it.

If you find anything off please contact me.

Size:
=====
24
30
48
60
72

Installation:
=============
for example
copy Pirate-cursor to ~/.icons directory
cp -r Pirate-cursor ~/.icons

Special Request:
===============
https://www.fiverr.com/share/oxP7mA

Follow Me:
=========
Instagram : @darkeye90shop
Mastadon: @darkeye90@social.opendesktop.org

Share your ‪‪❤︎‬:
=============
Pling me here on pling.com
Liberpay: https://liberapay.com/darkeye90/
Patreon:  https://www.patreon.com/darkeye90
Society6: https://society6.com/darkeye90


Special Thank:
===========
Generate (sizes) script
https://www.pling.com/p/1148692/


